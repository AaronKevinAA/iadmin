package response

import "ginProject/model"

type SysRoleResponse struct {
	Role model.SysRole `json:"role"`
}


