package response

import "ginProject/model"

type SysApiResponse struct {
	Api model.SysApi `json:"api"`
}
