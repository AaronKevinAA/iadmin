package utils

const (
	ConfigEnv                = "GVA_CONFIG"
	ConfigFile               = "config.yaml"
	DefaultPassword          = "123456"
	ExcelInPreviewDataWrong  = "<span style='color:red'>错误</span>"
	ExcelInPreviewDataUpdate = "<span style='color:Orange'>更新</span>"
	ExcelInPreviewDataCreate = "<span style='color:green'>新增</span>"
)
